import torch.nn as nn
import torch.nn.functional as F
from allennlp.nn.util import sort_batch_by_length, masked_softmax
from torch.nn.utils.rnn import pack_padded_sequence
from torch.nn.utils.rnn import pad_packed_sequence
import torch


class RNNSequenceModel(nn.Module):
    def __init__(self, num_classes, embedding_dim, hidden_size, num_layers, bidir=True,
                 dropout1=0.2, dropout2=0.2, dropout3=0.2):
        super(RNNSequenceModel, self).__init__()
        self.rnn = nn.LSTM(input_size=embedding_dim, hidden_size=hidden_size,
                           num_layers=num_layers, dropout=dropout2, batch_first=True, bidirectional=bidir)

        direc = 2 if bidir else 1
        self.output_projection = nn.Linear(hidden_size * direc, num_classes)


        self.dropout_on_input_to_LSTM = nn.Dropout(dropout1)
        self.dropout_on_input_to_linear_layer = nn.Dropout(dropout3)




    def forward(self, inputs, lengths):
        embedded_input = self.dropout_on_input_to_LSTM(inputs)
        (sorted_input, sorted_lengths, input_unsort_indices, _) = sort_batch_by_length(embedded_input, lengths)
        packed_input = pack_padded_sequence(sorted_input, sorted_lengths.data.tolist(), batch_first=True)
        packed_sorted_output, _ = self.rnn(packed_input)
        # Shape: (batch_size, sequence_length, hidden_size)
        sorted_output, _ = pad_packed_sequence(packed_sorted_output, batch_first=True)
        # Shape: (batch_size, sequence_length, hidden_size)
        output = sorted_output[input_unsort_indices]


        # (batch_size, sequence_length, hidden_size)
        input_encoding = self.dropout_on_input_to_linear_layer(output)
        # (batch_size, sequence_length, 2)
        unnormalized_output = self.output_projection(input_encoding)
        # Normalize with log softmax
        output_distribution = F.log_softmax(unnormalized_output, dim=-1)
        # print(output_distribution.size()) 64*句子长度*2
        return output_distribution